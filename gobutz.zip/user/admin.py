from django.contrib import admin
from .models import orderdata,blog_data

# Register your models here.
admin.site.register(orderdata)
admin.site.register(blog_data)
