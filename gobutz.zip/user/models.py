from django.db import models
import datetime

# Create your models here.
class orderdata(models.Model):
    user_id = models.AutoField
    user_name = models.CharField( max_length=30)
    user_email = models.EmailField()
    user_no = models.TextField()
    option = models.CharField(max_length=30)
    date = models.DateField(default=datetime.datetime.now())


    def __str__(self):
         return self.user_name


class blog_data(models.Model):
     blog_id = models.AutoField
     blog_head = models.CharField(max_length=50,default= " ,")
     blog_content = models.TextField(max_length=5000,default=",")
     blog_content11 = models.TextField(max_length=5000,default=",")
     blog_content12 = models.TextField(max_length=5000,default=",")
     blog_content13 = models.TextField(max_length=5000,default=",")
     blog_content14 = models.TextField(max_length=5000,default=",")
     blog_head1 = models.CharField(max_length=50,default= " ,")
     blog_content1 = models.TextField(max_length=5000,default=" ,")
     blog_head2 = models.CharField(max_length=50,default= " ,")
     blog_content2 = models.TextField(max_length=5000,default=" ,")
     blog_head3 = models.CharField(max_length=50,default= " ,")
     blog_content3 = models.TextField(max_length=5000,default=", ")
     blog_head4 = models.CharField(max_length=50,default=" ,")
     blog_content4 = models.TextField(max_length=5000,default= ", ")


     def __str__(self):
         return self.blog_head








"""  

    username vikashnishad
    email fudank239891@gmail.com
    password fudank249891vikash
    
    """


