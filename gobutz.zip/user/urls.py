from django.contrib import admin
from django.urls import path,include
from .import views

urlpatterns = [
   
    path('', views.Index,name = "indexpage"),
    path('home', views.Index,name = "indexpageb1"),
    path('product', views.Product,name = "indexpageb1"),
    path('current', views.Current,name = "indexpage1f"),
    path('blog', views.Blog,name = "indexpagbe1f"),
    path('contact', views.Contact,name = "indexpage51"),
    path('orderpage', views.Orderpage,name = "indexpage14"),
    path('order', views.Order,name = "indexpage31"),
    path('search', views.Search,name = "searchpage"),
    path('blg1', views.blg1,name = "blgpage"),
    path('blg2', views.blg2,name = "blgpage"),
    path('blg3', views.blg3,name = "blgpage"),
    path('blg4', views.blg4,name = "blgpage"),
    path('blg5', views.blg5,name = "blgpage"),
    path('blg6', views.blg6,name = "blgpage"),
    path('blg7', views.blg7,name = "blgpage"),
    path('blg8', views.blg8,name = "blgpage"),
    path('blg9', views.blg9,name = "blgpage"),
    path('blg10', views.blg10,name = "blgpage"),

]