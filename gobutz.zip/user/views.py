from django.shortcuts import render,HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages
from .models import orderdata,blog_data
from math import ceil
from django.contrib import messages

# Create your views here.


def Index(request):
    return render(request,"user/index.html")



def Product(request):
    return render(request,"user/product.html")


def Current(request):
    return render(request,"user/current.html")

def Contact(request):
    return render(request,"user/contact.html")

  




def Blog(request):
    all_datap = blog_data.objects.all()
    dlist=[]
    nlist=[0]
    data_list = []
    n = len(all_datap)
    nnlist = []
    a = 0
    nnlist = []
    for i in range(n):
        nlist=[a]
        nnlist.append(nlist)
        a = a+1
    for i in range(n):
        dlist.append(i)
    
    for j in dlist:
        bylist = all_datap[j]
        data_list.append(bylist)
    data_dict = {'dlist':data_list,'nlist':nlist}
    return render(request,"user/blog.html",data_dict)





def Orderpage(request):
    return render(request,"user/orderpage.html")   


def Order(request):
    option1 = request.POST['option']   
    
    user_name1 = request.POST['user_name']
    user_email1 = request.POST['user_email']
    user_no1 = request.POST['user_no']

    orders = orderdata(user_name = user_name1, user_email = user_email1,
    user_no = user_no1, option = option1)

    orders.save()
    print("hhh")
    return render(request,"user/index.html")
        
"""
def Search(request):
    search = request.Get('searching')
     return render(request,"user/blog.html")
     messages.success(request,'something invalid 3')
     from django.contrib import messages
"""
"""
def Search(request):
    search = request.GET['searching']
    if (search==''):
        search= 'website'
    all_datap = blog_data.objects.filter(blog_head__icontains = search)
    dlist=[]
    nlist=[0]
    data_list = []
    n = len(all_datap)
    for i in range(n):
        dlist.append(i)
    for j in dlist:
        bylist = all_datap[j]
        data_list.append(bylist)
    data_dict = {'dlist':data_list,'nlist':nlist}
    messages.success(request,'your searching result ')
    return render(request,"user/blog.html",data_dict)
"""


def Search(request):
    search = request.GET['searching']
    if (search==''):
        search= 'website'

    all_datap = blog_data.objects.filter(blog_head__icontains = search)

    if all_datap:
        dlist=[]
        nlist=[0]
        data_list = []
        n = len(all_datap)
        for i in range(n):
            dlist.append(i)
        for j in dlist:
            bylist = all_datap[j]
            data_list.append(bylist)
        data_dict = {'dlist':data_list,'nlist':nlist}
    
        return render(request,"user/blog.html",data_dict)  
    else:
        fresult = "sorry. Please Search different keyword with related query..."
        return render(request,"user/blog.html",{"fr":fresult})
            


    

    





"""

def Search(request):
    ss_get = searchform(request.GET)
    ss_out = ss_get.data['search_input']
    if (ss_out==''):
        ss_out= 'mob'

    all_datap = product_show.objects.filter(product_name__contains = ss_out)
    dlist=[]
    nlist=[]
    data_list = []
    a = 0
    n = len(all_datap)
    n1 = ceil(n/5)
    for i in range(n1):
        nlist.append(i)
        
    for i in range(n):
        dlist.append(i)
        
    
    for j in dlist:
        bylist = all_datap[j]
        data_list.append(bylist)
    data_dict = {'dlist':data_list,'nlist':nlist}

    return render(request, 'search_result1.html',data_dict)
    """





def blg1(request):
    all_datap = blog_data.objects.filter(blog_head__icontains= "learn").filter(blog_head__icontains="web")
    dlist=[]
    nlist=[0]
    data_list = []
    n = len(all_datap)
    nnlist = []
    a = 0
    nnlist = []
    for i in range(n):
        nlist=[a]
        nnlist.append(nlist)
        a = a+1
    for i in range(n):
        dlist.append(i)
    
    for j in dlist:
        bylist = all_datap[j]
        data_list.append(bylist)
    data_dict = {'dlist':data_list,'nlist':nlist}
    return render(request,"user/blog.html",data_dict)

def blg1(request):
    all_datap = blog_data.objects.filter(blog_head__icontains= "website").filter(blog_content__contains=
    "django").filter(blog_content__contains="model").filter(blog_content__contains=
    "python").filter(blog_content__contains="this").filter(blog_content__contains="temp")
    dlist=[]
    nlist=[0]
    data_list = []
    n = len(all_datap)
    nnlist = []
    a = 0
    nnlist = []
    for i in range(n):
        nlist=[a]
        nnlist.append(nlist)
        a = a+1
    for i in range(n):
        dlist.append(i)
    
    for j in dlist:
        bylist = all_datap[j]
        data_list.append(bylist)
    data_dict = {'dlist':data_list,'nlist':nlist}
    return render(request,"user/blog.html",data_dict)

def blg2(request):
    all_datap = blog_data.objects.filter(blog_head__icontains= "data").filter(blog_head__icontains=
    "sci").filter(blog_content__icontains="machine").filter(blog_content__icontains="deep").filter(blog_content__icontains=
    "rnn").filter(blog_content__icontains="cnn").filter(blog_content__icontains="knn").filter(blog_content__icontains=
    "model").filter(blog_content__icontains="algorithm").filter(blog_content__icontains="python").filter(blog_content__icontains=
    "science")
    dlist=[]
    nlist=[0]
    data_list = []
    n = len(all_datap)
    nnlist = []
    a = 0
    nnlist = []
    for i in range(n):
        nlist=[a]
        nnlist.append(nlist)
        a = a+1
    for i in range(n):
        dlist.append(i)
    
    for j in dlist:
        bylist = all_datap[j]
        data_list.append(bylist)
    data_dict = {'dlist':data_list,'nlist':nlist}
    return render(request,"user/blog.html",data_dict)

def blg3(request):
    all_datap = blog_data.objects.filter(blog_head__icontains= "machine").filter(blog_content__icontains="model")
    dlist=[]
    nlist=[0]
    data_list = []
    n = len(all_datap)
    nnlist = []
    a = 0
    nnlist = []
    for i in range(n):
        nlist=[a]
        nnlist.append(nlist)
        a = a+1
    for i in range(n):
        dlist.append(i)
    
    for j in dlist:
        bylist = all_datap[j]
        data_list.append(bylist)
    data_dict = {'dlist':data_list,'nlist':nlist}
    return render(request,"user/blog.html",data_dict)

def blg4(request):
    all_datap = blog_data.objects.filter(blog_head__icontains= "deep").filter(blog_content__icontains="algorithm")
    dlist=[]
    nlist=[0]
    data_list = []
    n = len(all_datap)
    nnlist = []
    a = 0
    nnlist = []
    for i in range(n):
        nlist=[a]
        nnlist.append(nlist)
        a = a+1
    for i in range(n):
        dlist.append(i)
    
    for j in dlist:
        bylist = all_datap[j]
        data_list.append(bylist)
    data_dict = {'dlist':data_list,'nlist':nlist}
    return render(request,"user/blog.html",data_dict)

def blg5(request):
    all_datap = blog_data.objects.filter(blog_head__icontains= "python").filter(blog_content__contains="basic")
    dlist=[]
    nlist=[0]
    data_list = []
    n = len(all_datap)
    nnlist = []
    a = 0
    nnlist = []
    for i in range(n):
        nlist=[a]
        nnlist.append(nlist)
        a = a+1
    for i in range(n):
        dlist.append(i)
    
    for j in dlist:
        bylist = all_datap[j]
        data_list.append(bylist)
    data_dict = {'dlist':data_list,'nlist':nlist}
    return render(request,"user/blog.html",data_dict)   



def blg6(request):
    all_datap = blog_data.objects.filter(blog_head__icontains= "javascript").filter(blog_head__icontains="java")
    dlist=[]
    nlist=[0]
    data_list = []
    n = len(all_datap)
    nnlist = []
    a = 0
    nnlist = []
    for i in range(n):
        nlist=[a]
        nnlist.append(nlist)
        a = a+1
    for i in range(n):
        dlist.append(i)
    
    for j in dlist:
        bylist = all_datap[j]
        data_list.append(bylist)
    data_dict = {'dlist':data_list,'nlist':nlist}
    return render(request,"user/blog.html",data_dict)

def blg7(request):
    all_datap = blog_data.objects.filter(blog_head__icontains= "html").filter(blog_head__icontains="css")
    dlist=[]
    nlist=[0]
    data_list = []
    n = len(all_datap)
    nnlist = []
    a = 0
    nnlist = []
    for i in range(n):
        nlist=[a]
        nnlist.append(nlist)
        a = a+1
    for i in range(n):
        dlist.append(i)
    
    for j in dlist:
        bylist = all_datap[j]
        data_list.append(bylist)
    data_dict = {'dlist':data_list,'nlist':nlist}
    return render(request,"user/blog.html",data_dict)

def blg8(request):
    all_datap = blog_data.objects.filter(blog_head__icontains= "startup").filter(blog_content__icontains="starup")
    dlist=[]
    nlist=[0]
    data_list = []
    n = len(all_datap)
    nnlist = []
    a = 0
    nnlist = []
    for i in range(n):
        nlist=[a]
        nnlist.append(nlist)
        a = a+1
    for i in range(n):
        dlist.append(i)
    
    for j in dlist:
        bylist = all_datap[j]
        data_list.append(bylist)
    data_dict = {'dlist':data_list,'nlist':nlist}
    return render(request,"user/blog.html",data_dict)


def blg9(request):
    all_datap = blog_data.objects.filter(blog_head__icontains= "bus").filter(blog_content__icontains="business")
    dlist=[]
    nlist=[0]
    data_list = []
    n = len(all_datap)
    nnlist = []
    a = 0
    nnlist = []
    for i in range(n):
        nlist=[a]
        nnlist.append(nlist)
        a = a+1
    for i in range(n):
        dlist.append(i)
    
    for j in dlist:
        bylist = all_datap[j]
        data_list.append(bylist)
    data_dict = {'dlist':data_list,'nlist':nlist}
    return render(request,"user/blog.html",data_dict)


def blg10(request):
    all_datap = blog_data.objects.filter(blog_head__icontains= "support").filter(blog_content__icontains="help")
    dlist=[]
    nlist=[0]
    data_list = []
    n = len(all_datap)
    nnlist = []
    a = 0
    nnlist = []
    for i in range(n):
        nlist=[a]
        nnlist.append(nlist)
        a = a+1
    for i in range(n):
        dlist.append(i)
    
    for j in dlist:
        bylist = all_datap[j]
        data_list.append(bylist)
    data_dict = {'dlist':data_list,'nlist':nlist}
    return render(request,"user/blog.html",data_dict)








